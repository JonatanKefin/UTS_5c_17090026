-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 11:43 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tpdb_daftar`
--

CREATE TABLE `tpdb_daftar` (
  `id` int(13) NOT NULL,
  `nama_siswa` varchar(30) NOT NULL,
  `tempat_lahir` varchar(30) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` enum('Laki - laki','Perempuan') NOT NULL,
  `sekolah` varchar(20) NOT NULL,
  `nisn` varchar(30) NOT NULL,
  `orang_tua` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `rt` varchar(5) NOT NULL,
  `rw` varchar(5) NOT NULL,
  `desa` varchar(20) NOT NULL,
  `kecamatan` varchar(20) NOT NULL,
  `kota` varchar(30) NOT NULL,
  `provinsi` varchar(30) NOT NULL,
  `no_tlp` char(12) NOT NULL,
  `foto` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tpdb_daftar`
--

INSERT INTO `tpdb_daftar` (`id`, `nama_siswa`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `sekolah`, `nisn`, `orang_tua`, `alamat`, `rt`, `rw`, `desa`, `kecamatan`, `kota`, `provinsi`, `no_tlp`, `foto`) VALUES
(2, 'haris', 'tegal', '2012-11-06', 'Laki - laki', 'smp  1 pemalang', '0123', 'haris', 'haris', '1', '2', 'haris', 'haris', 'tegal', 'jawa tengah', '0123', '797377.zip'),
(3, 'jonatan', 'tegal', '2013-11-04', 'Laki - laki', 'smp n 4 tegal', '08881432425', 'jonatan', 'jonayan', '4', '10', 'mintaragen', 'tegal timur', 'tegal', 'jawa tengah', '99988811342', '712553.rar'),
(4, 'puput', 'pemalang', '2012-11-14', 'Perempuan', 'smp  1 pemalang', '998931532423', 'puputt', 'pemalang', '5', '6', 'pemalang', 'pemalang', 'pemalang', 'jawa tengah', '813878868146', '753557.zip');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tpdb_daftar`
--
ALTER TABLE `tpdb_daftar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tpdb_daftar`
--
ALTER TABLE `tpdb_daftar`
  MODIFY `id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

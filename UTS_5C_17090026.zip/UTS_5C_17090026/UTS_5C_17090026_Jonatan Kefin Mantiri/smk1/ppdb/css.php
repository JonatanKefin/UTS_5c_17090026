	
<link rel="stylesheet" href="../assets/css/main.css" />
<!-- Date Picker CSS -->
<link rel="stylesheet" href="../assets/jquery-ui-1.11.4/smoothness/jquery-ui.css" rel="stylesheet" />

<!-- Date Picker JS -->
<script src="../assets/jquery-ui-1.11.4/jquery-ui.js"></script>

<script>
 $(function() {
  $("#tanggal").datepicker({
    dateFormat: 'yy/mm/dd',
    changeMonth: true,
    changeYear: true
   
  });
});
  </script>

	</head>
<?php
include('psb-koneksi.php');

$a=true;
if($_POST['nama']==""){
echo "Data tidak boleh kosong";
$a=false;
}
$b=true;
if($_POST['tempat_lahir']==""){
	echo "Data tidak boleh kosong";
	$b=false;
}
$c=true;
if($_POST['tanggal']==""){
	echo "Data tidak boleh kosong";
$c=false;
}
$d=true;
if($_POST['jenis_kelamin']==""){
	echo "Data tidak boleh kosong";
$d=false;
}
$e=true;
if($_POST['sekolah']==""){
	echo "Data tidak boleh kosong";
$e=false;
}
$f=true;
if($_POST['nisn']==""){
	echo "Data tidak boleh kosong";
$f=flase;
}
$g=true;
if($_POST['orang_tua']==""){
	echo "Data tidak boleh kosong";
$g=false;
}
$h=true;
if($_POST['alamat']==""){
	echo "Data tidak boleh kosong";
$h=false;
}
$h2=true;
if($_POST['rt']==""){
	echo "Data tidak boleh kosong";
$h2=false;
}
$h3=true;
if($_POST['rw']==""){
	echo "Data tidak boleh kosong";
$h3=false;
}
$h4=true;
if($_POST['desa']==""){
	echo "Data tidak boleh kosong";
$h4=false;
}
$h5=true;
if($_POST['kecamatan']==""){
	echo "Data tidak boleh kosong";
$h5=false;
}
$i=true;
if($_POST['kota']==""){
	echo "Data tidak boleh kosong";
$i=false;
}
$j=true;
if($_POST['provinsi']==""){
	echo "Data tidak boleh kosong";
$j=false;
}
$k=true;
if($_POST['no_tlp']==""){
	echo "Data tidak boleh kosong";
$k=false;
}
					
$cek=($a&&$b&&$c&&$d&&$e&&$f&&$g&&$h&&$h2&&$h3&&$h4&&$h5&&$i&&$j&&$k)?true:false;

if($cek==true){//cek lagi apakan semua sudah diisi

$imgFile = $_FILES['foto']['name'];
$tmp_dir = $_FILES['foto']['tmp_name'];
$imgSize = $_FILES['foto']['size'];

$upload_dir = 'file/';
$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); 
$valid_extensions = array('zip', 'rar'); 
$itempic = rand(1000,1000000).".".$imgExt; //rename kedalam angka

	//validasi ektensi gambar b2
			if(in_array($imgExt, $valid_extensions)){			
		//jika gambar lebih besar
				if(!$imgSize< 2000000)				{
					move_uploaded_file($tmp_dir,$upload_dir.$itempic);
	$perintah=sprintf("INSERT INTO tpdb_daftar
	VALUES('null','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','$itempic')",
	$_POST['nama'],
	$_POST['tempat_lahir'],
	$_POST['tanggal'],
	$_POST['jenis_kelamin'],
	$_POST['sekolah'],
	$_POST['nisn'],
	$_POST['orang_tua'],
	$_POST['alamat'],
	$_POST['rt'],
	$_POST['rw'],
	$_POST['desa'],
	$_POST['kecamatan'],
	$_POST['kota'],
	$_POST['provinsi'],
	$_POST['no_tlp'],'$status_siswa','$itempic');
$query=mysqli_query($koneksi,$perintah);
if(!$query) {
				echo "Akses Gagal<br/>";
				echo "ERROR:".mysqli_error();
				}
				else{					
			echo "<script>alert('Data berhasil disimpan!')</script>";
				}
			}
			//jika file terlalu besar
			
			else{
			echo "<script>alert('Maaf file terlalu besar.')</script>";	
			echo "<script>window.open('daftar','_self')</script>";
			}
	//jika file terlalu besar b1

}
//validasi ektensi file b2
			else{
				
	echo "<script>alert('Maaf file tidak sesuai atau file kosong.')</script>";				
	echo "<script>window.open('daftar','_self')</script>";
				
			}
}
?>
<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "ppdb";
$koneksi=mysqli_connect($host,$user,$password);
if(!$koneksi){
    echo "Gagal melakukan koneksi <br/>:".mysqli_connect_error();
    exit();
    
}
$pilihdb=mysqli_select_db($koneksi,$db);
if(!$pilihdb){
    exit ("Gagal melakukan hubungan dengan database<br> Kesalahan :".mysqli_error());
}

?>
